$(document).ready(function () {
    $(function () {
        $("#datepicker").datepicker();
    });
    $(".cross").hide();
    $(".menu").hide();
    $('.overlay').hide();
    $(".hamburger").click(function () {
        $('.overlay').show();
        $(".menu").slideToggle("fast", function () {
            $(".hamburger").hide();
            $(".cross").show();
        });
    });
    $(".cross").click(function () {
        $(".menu").slideToggle("fast", function () {
            $('.overlay').hide();
            $(".cross").hide();
            $(".hamburger").show();
        });
    });
    $('.selectelement').on('click', 'a', function () {
        $('.selectelement a').removeClass('active');
        $(this).addClass('active');
    });
    $('.headelement').on('click', 'a', function () {
        $('.headelement a').removeClass('active');
        $(this).addClass('active');
    });
    $('.footerlinks').on('click', 'a', function () {
        $('.footerlinks a').removeClass('active');
        $(this).addClass('active');
    });
    $(".hamburger").click(function () {
        $('body').css('overflow', 'hidden');
    });
    $(".cross").click(function () {
        $('body').css('overflow', 'scroll');
    });
    $("input[class='file-custom']").click(function () {
        $("input[id='file']").click();
    });
    $("input[class='file']").change(function (e) {
        var $this = $(this);
        $this.next().html($this.val().split('\\').pop());
    });
});